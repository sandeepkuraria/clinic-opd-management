package com.spring.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.rmi.ServerException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.models.Doctor;
import com.spring.service.Doctor.DoctorServiceInterface;

//@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/Doctor")
public class DoctorController {
	
	@Autowired
	private DoctorServiceInterface doctorServiceInterface;
	
	@GetMapping("/show")
    public List<Doctor> groups() {		
		return doctorServiceInterface.showAll();
    }


	@PostMapping("/Doctor_Registration")
	public ResponseEntity<Doctor> addResource(@RequestBody Doctor r) throws URISyntaxException 
	{			
		 Doctor d= doctorServiceInterface.addDoctor(r); 
		 return ResponseEntity.created(new URI("/Doctor/Doctor_Registration/"+d.getDocotor_id())).body(d);  				
	}
	
	@GetMapping("/hello")
	public String hello()
	{
		return "hello";
	}
	

	
	@PostMapping("/signin")
	public ResponseEntity<?> authenticateDoctor(@RequestBody Doctor r) {
		System.out.println("in auth " + r);
		// API : o.s.http.ResponseEntity<T> (T body,HttpStatus stsCode)
		
//		  Object o=doctorServiceInterface.authenticateDoctor(r.getEmail(), r.getPassword());
			
		return new ResponseEntity<>(
				doctorServiceInterface.authenticateDoctor(r.getEmail(), r.getPassword()), HttpStatus.OK);

	}
     
//     @RequestMapping(value = {"/logout"}, method = RequestMethod.POST)
//     public String logoutDo(HttpServletRequest request,HttpServletResponse response)
//     {
//     
//   
//         return "redirect:/login";
//     }
	
	 @GetMapping("/findDoctor/{id}")
		public Optional<Doctor> findDoctor(@PathVariable int id)
		{	
			return doctorServiceInterface.findDoctorbyId(id);
		}
	 
	 @GetMapping("/showAppointments/{id}")
	 public String showAppointment(@PathVariable int id)
	 {
		 return " ";
	 }
	 
	 @DeleteMapping("/delete/{userId}")
	    public void deleteUser(@PathVariable Long userId) {
	        this.doctorServiceInterface.deleteById(userId);
	    }
	 
	    @PutMapping("/update")
	    public ResponseEntity<Doctor> create(@RequestBody Doctor newUser) throws ServerException {
	    	Doctor user = doctorServiceInterface.save(newUser);
	        if (user == null) {
	            throw new ServerException("update failed");
	        } else {
	            return new ResponseEntity<>(user, HttpStatus.CREATED);
	        }
	    }
	    
	    @GetMapping("/findDoctorSpecial/{Special}")
		public List<Doctor> findDoctorBySpecial(@PathVariable String Special)
		{	
			return doctorServiceInterface.findDoctorBySpecial(Special);
		}
	    
	
	
}
